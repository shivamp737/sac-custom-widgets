/**
 * SAC Custom Widget — Calendar Table v7
 * Version: 1.0.5
 *
 * v7: Added DependentOnIds and TriggerStatuses columns from CalendarDependencies
 */
(function () {

  /* ------------------------------------------------------------------ */
  /* Column configuration                                                 */
  /* ------------------------------------------------------------------ */
  var COL_CFG = {
    'Type':          { width:  85, type: 'type'     },
    'ID':            { width: 145, type: 'id-plain'  },
    'Name':          { width: 200, type: 'text'     },
    'Description':   { width: 170, type: 'text'     },
    'Calendar Task Type': { width: 155, type: 'text'     },
    'Status':        { width: 155, type: 'status'   },
    'Owner':         { width: 105, type: 'text'     },
    'Assignee':      { width: 190, type: 'text'     },
    'Viewers':       { width: 170, type: 'text'     },
    'ParentID':      { width: 145, type: 'id-plain'  },
    'StartDate':     { width: 100, type: 'text'     },
    'EndDate':       { width: 100, type: 'text'     },
    'Progress':          { width: 130, type: 'progress' },
    'DependentOnIds':    { width: 160, type: 'text'     },
    'TriggerStatuses':   { width: 160, type: 'text'     },
    'MemberDimId':       { width: 115, type: 'text', ctx: true },
    'MemberId':      { width: 180, type: 'text'     },
    'MemberDesc':    { width: 115, type: 'text'     },
    'MemberModelId': { width: 180, type: 'id-plain'  }
  };

  /* ------------------------------------------------------------------ */
  /* Template                                                             */
  /* ------------------------------------------------------------------ */
  var tmpl = document.createElement('template');
  tmpl.innerHTML = [
    '<style>',
    '  :host {',
    '    display: block; width: 100%; height: 100%;',
    '    font-family: "72", "72full", Arial, Helvetica, sans-serif;',
    '    font-size: 14px; color: #1d2d3e;',
    '    background: #ffffff; overflow: hidden;',
    '  }',
    '  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }',
    '  .ct-root { display: flex; flex-direction: column; width: 100%; height: 100%; overflow: hidden; }',

    /* toolbar */
    '  .ct-toolbar {',
    '    display: flex; align-items: center; justify-content: space-between;',
    '    padding: 8px 14px; background: #f5f6f7;',
    '    border-bottom: 1px solid #d9dbdd; flex-shrink: 0;',
    '  }',
    '  .ct-tl { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }',
    '  .ct-tr { display: flex; align-items: center; gap: 8px; }',
    '  .ct-title { font-size: 13px; font-weight: 700; color: #1d2d3e; margin-right: 4px; }',

    /* pills */
    '  .ct-pill { border-radius: 10px; padding: 2px 8px; font-size: 11px; font-weight: 600; }',
    '  .ct-pill-blue { background: #e1f4ff; color: #0070f2; }',
    '  .ct-pill-grey { background: #eaecee; color: #556b82; }',

    /* buttons */
    '  .ct-btn {',
    '    border: none; border-radius: 4px; padding: 5px 12px;',
    '    font-size: 12px; font-family: inherit; cursor: pointer; font-weight: 600;',
    '  }',
    '  .ct-btn-csv   { background: #0070f2; color: #ffffff; }',
    '  .ct-btn-xls   { background: #1b7a34; color: #ffffff; }',
    '  .ct-btn-csv:hover:not(:disabled) { background: #0040b0; }',
    '  .ct-btn-xls:hover:not(:disabled) { background: #145c27; }',
    '  .ct-btn:disabled { opacity: 0.4; cursor: not-allowed; }',

    /* content */
    '  .ct-content { flex: 1; display: flex; flex-direction: column; overflow: hidden; position: relative; }',

    /* empty state */
    '  .ct-empty {',
    '    display: flex; flex-direction: column; align-items: center; justify-content: center;',
    '    flex: 1; gap: 10px; padding: 24px; color: #89919a;',
    '  }',
    '  .ct-empty-icon  { font-size: 36px; opacity: 0.3; }',
    '  .ct-empty-title { font-size: 14px; font-weight: 600; color: #5b738b; }',
    '  .ct-empty-hint  { font-size: 12px; color: #aaadb0; text-align: center; line-height: 1.6; }',

    /* table wrapper */
    '  .ct-tbl-wrap { flex: 1; overflow: auto; }',
    '  table { border-collapse: collapse; font-size: 14px; table-layout: fixed; }',

    /* header */
    '  thead tr { background: #0070f2; color: #ffffff; position: sticky; top: 0; z-index: 2; }',
    '  thead th {',
    '    padding: 8px 12px; text-align: left; font-weight: 600; white-space: nowrap;',
    '    font-size: 13px; overflow: hidden; text-overflow: ellipsis;',
    '    position: relative; user-select: none;',
    '  }',
    '  thead th.ct-ctx-sep { border-left: 3px solid rgba(255,255,255,0.5); }',

    /* resize handle */
    '  .ct-resizer {',
    '    position: absolute; right: 0; top: 0; height: 100%;',
    '    width: 6px; cursor: col-resize; z-index: 3;',
    '    background: transparent;',
    '  }',
    '  .ct-resizer:hover, .ct-resizer.ct-resizing { background: rgba(255,255,255,0.45); }',

    /* rows — report style: clean alternating, bottom border only */
    '  tbody tr.ct-row-ev { background: #eef4fb; }',
    '  tbody tr.ct-row-ch:nth-child(even) { background: #f7f9fc; }',
    '  tbody tr.ct-row-ch:nth-child(odd)  { background: #ffffff; }',
    '  tbody tr:hover td  { background: #ddeeff !important; }',
    '  tbody td {',
    '    padding: 7px 12px; border-bottom: 1px solid #e8eaec;',
    '    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;',
    '    cursor: pointer; font-size: 14px;',
    '  }',
    '  tbody td.ct-ctx-sep { border-left: 3px solid #c8d7e4; }',
    '  tbody td.ct-flash { background: #c8f0d1 !important; transition: background 0s; }',

    /* type badges */
    '  .ct-badge { display: inline-block; padding: 2px 9px; border-radius: 10px; font-size: 12px; font-weight: 700; }',
    '  .ct-badge-ev { background: #0070f2; color: #ffffff; }',
    '  .ct-badge-ch { background: #e8f3ff; color: #0070f2; border: 1px solid #91c8f6; }',

    /* status chips — all 9 official CalendarTaskStatus values */
    '  .ct-status { display: inline-block; padding: 2px 9px; border-radius: 10px; font-size: 12px; font-weight: 600; white-space: nowrap; }',
    '  .ct-s-open                { background: #e1f4ff; color: #0070f2; }',
    '  .ct-s-inprogress          { background: #fff3cd; color: #8a6000; }',
    '  .ct-s-onhold              { background: #f3e5f5; color: #6a1b9a; }',
    '  .ct-s-canceled            { background: #fce4ec; color: #c0143c; }',
    '  .ct-s-successful          { background: #e8f5e9; color: #1b7a34; }',
    '  .ct-s-failed              { background: #ffebee; color: #b71c1c; }',
    '  .ct-s-inactive            { background: #f5f6f7; color: #89919a; }',
    '  .ct-s-noassignee          { background: #fff8e1; color: #e65100; }',
    '  .ct-s-partiallysuccessful { background: #e0f2f1; color: #00695c; }',
    '  .ct-s-unknown             { background: #f5f6f7; color: #89919a; border: 1px dashed #c5c5c5; }',

    /* progress bar */
    '  .ct-prog { display: flex; align-items: center; gap: 6px; }',
    '  .ct-prog-track { flex: 1; height: 7px; background: #e8eaec; border-radius: 4px; overflow: hidden; min-width: 40px; }',
    '  .ct-prog-fill  { height: 100%; border-radius: 4px; }',
    '  .ct-prog-lbl   { font-size: 12px; color: #556b82; white-space: nowrap; min-width: 36px; text-align: right; font-weight: 600; }',

    /* id-plain cells — normal font, slightly muted, no monospace */
    '  .ct-id-plain { font-size: 13px; color: #556b82; }',

    /* copy toast */
    '  .ct-toast {',
    '    position: absolute; bottom: 36px; left: 50%; transform: translateX(-50%);',
    '    background: #1d2d3e; color: #fff; padding: 5px 14px;',
    '    border-radius: 20px; font-size: 12px; pointer-events: none;',
    '    opacity: 0; transition: opacity 0.15s; z-index: 99; white-space: nowrap;',
    '  }',
    '  .ct-toast.ct-toast-show { opacity: 1; }',

    /* footer */
    '  .ct-footer {',
    '    padding: 5px 14px; font-size: 12px; color: #aaadb0;',
    '    background: #fafafa; border-top: 1px solid #e8eaec; flex-shrink: 0;',
    '  }',
    '</style>',

    '<div class="ct-root">',
    '  <div class="ct-toolbar">',
    '    <div class="ct-tl">',
    '      <span class="ct-title">Calendar Events</span>',
    '    </div>',
    '    <div class="ct-tr">',
    '      <button class="ct-btn ct-btn-csv" id="ct-dl-csv" disabled>&#8659;&nbsp;Download CSV</button>',
    '      <button class="ct-btn ct-btn-xls" id="ct-dl-xls" disabled>&#8659;&nbsp;Export Excel</button>',
    '    </div>',
    '  </div>',
    '  <div class="ct-content" id="ct-content">',
    '    <div class="ct-empty">',
    '      <div class="ct-empty-icon">&#128197;</div>',
    '      <div class="ct-empty-title">No data loaded</div>',
    '      <div class="ct-empty-hint">Run the SAC script to load calendar data.<br>The table will appear here automatically.</div>',
    '    </div>',
    '  </div>',
    '  <div class="ct-toast" id="ct-toast">Copied!</div>',
    '</div>'
  ].join('\n');

  /* ------------------------------------------------------------------ */
  /* Web Component                                                        */
  /* ------------------------------------------------------------------ */
  class CalendarTable extends HTMLElement {

    constructor() {
      super();
      this._shadowRoot = this.attachShadow({ mode: 'open' });
      this._shadowRoot.appendChild(tmpl.content.cloneNode(true));
      this._props   = { tableData: '' };
      this._headers = [];
      this._rows    = [];
      this._toastTimer = null;

      this._shadowRoot.getElementById('ct-dl-csv')
        .addEventListener('click', this._onCsvClick.bind(this));
      this._shadowRoot.getElementById('ct-dl-xls')
        .addEventListener('click', this._onXlsClick.bind(this));
    }

    connectedCallback() {
      if (this._props.tableData) {
        this._parse(this._props.tableData);
        this._render();
      }
    }

    onCustomWidgetBeforeUpdate(changedProperties) {
      Object.assign(this._props, changedProperties);
    }

    onCustomWidgetAfterUpdate(changedProperties) {
      if ('tableData' in changedProperties) {
        this._parse(this._props.tableData);
        this._render();
      }
    }

    get tableData()      { return this._props.tableData; }
    set tableData(value) {
      this._props.tableData = (value && typeof value === 'string') ? value : '';
      this._parse(this._props.tableData);
      this._render();
    }

    setTableData(data) { this.tableData = (data && typeof data === 'string') ? data : ''; }
    clearTable()       { this.tableData = ''; }

    /* ---- helpers ---- */

    _esc(v) {
      var s = (v !== undefined && v !== null) ? String(v) : '';
      if (s === 'undefined') { s = ''; }
      return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    _statusClass(s) {
      var map = {
        'Open':'ct-s-open','InProgress':'ct-s-inprogress','OnHold':'ct-s-onhold',
        'Canceled':'ct-s-canceled','Successful':'ct-s-successful','Failed':'ct-s-failed',
        'Inactive':'ct-s-inactive','NoAssignee':'ct-s-noassignee',
        'PartiallySuccessful':'ct-s-partiallysuccessful'
      };
      return (s && map[s]) ? map[s] : 'ct-s-unknown';
    }

    _progressBar(val) {
      var num = parseInt(val, 10);
      if (isNaN(num)) { num = 0; }
      if (num < 0)   { num = 0; }
      if (num > 100) { num = 100; }
      var colour = num === 100 ? '#1b7a34' : num >= 50 ? '#0070f2' : '#e65100';
      return '<div class="ct-prog">' +
        '<div class="ct-prog-track">' +
          '<div class="ct-prog-fill" style="width:' + num + '%;background:' + colour + ';"></div>' +
        '</div>' +
        '<span class="ct-prog-lbl">' + this._esc(val) + '</span>' +
        '</div>';
    }

    _parse(raw) {
      this._headers = [];
      this._rows    = [];
      if (!raw || !raw.trim()) return;
      var lines = raw.split('\n');
      var clean = [];
      for (var i = 0; i < lines.length; i++) {
        if (lines[i].trim()) { clean.push(lines[i]); }
      }
      if (clean.length === 0) return;
      this._headers = clean[0].split('\t');
      for (var j = 1; j < clean.length; j++) {
        this._rows.push(clean[j].split('\t'));
      }
    }

    /* ---- copy to clipboard ---- */

    _copyText(text) {
      var self = this;
      var done = false;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function() {
          self._showToast('Copied!');
        }).catch(function() {
          self._fallbackCopy(text);
        });
        done = true;
      }
      if (!done) { this._fallbackCopy(text); }
    }

    _fallbackCopy(text) {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity  = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      try {
        document.execCommand('copy');
        this._showToast('Copied!');
      } catch (e) {
        this._showToast('Select & copy manually');
      }
      document.body.removeChild(ta);
    }

    _showToast(msg) {
      var toast = this._shadowRoot.getElementById('ct-toast');
      if (!toast) return;
      toast.textContent = msg;
      toast.classList.add('ct-toast-show');
      var self = this;
      if (self._toastTimer) { clearTimeout(self._toastTimer); }
      self._toastTimer = setTimeout(function() {
        toast.classList.remove('ct-toast-show');
      }, 1500);
    }

    /* ---- column resizing ---- */

    _wireResizers() {
      var self = this;
      var ths  = self._shadowRoot.querySelectorAll('thead th');
      for (var i = 0; i < ths.length; i++) {
        (function(th, idx) {
          var rz = th.querySelector('.ct-resizer');
          if (!rz) return;
          var startX = 0, startW = 0;
          rz.addEventListener('mousedown', function(e) {
            var cols = self._shadowRoot.querySelectorAll('col');
            startX   = e.clientX;
            startW   = cols[idx] ? (parseInt(cols[idx].style.width, 10) || 120) : 120;
            rz.classList.add('ct-resizing');
            function onMove(ev) {
              var w   = Math.max(50, startW + ev.clientX - startX);
              var tbl = self._shadowRoot.querySelector('table');
              if (cols[idx]) { cols[idx].style.width = w + 'px'; }
              if (tbl) {
                var total = 0;
                var all   = self._shadowRoot.querySelectorAll('col');
                for (var k = 0; k < all.length; k++) {
                  total += parseInt(all[k].style.width, 10) || 120;
                }
                tbl.style.width = total + 'px';
              }
            }
            function onUp() {
              rz.classList.remove('ct-resizing');
              document.removeEventListener('mousemove', onMove);
              document.removeEventListener('mouseup',   onUp);
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup',   onUp);
            e.preventDefault();
            e.stopPropagation();
          });
        })(ths[i], i);
      }
    }

    /* ---- wire cell copy clicks ---- */

    _wireCellClicks() {
      var self = this;
      var tds  = self._shadowRoot.querySelectorAll('tbody td');
      for (var i = 0; i < tds.length; i++) {
        (function(td) {
          td.addEventListener('click', function() {
            var val = td.getAttribute('data-val') || '';
            if (!val) return;
            self._copyText(val);
            td.classList.add('ct-flash');
            setTimeout(function() { td.classList.remove('ct-flash'); }, 600);
          });
        })(tds[i]);
      }
    }

    /* ---- CSV download ---- */

    _onCsvClick() {
      if (!this._props.tableData) return;
      var csv   = '\uFEFF'; /* UTF-8 BOM for Excel CSV compatibility */
      var lines = this._props.tableData.split('\n');
      for (var i = 0; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        var cols = lines[i].split('\t');
        var row  = '';
        for (var j = 0; j < cols.length; j++) {
          var c    = cols[j] || '';
          var cell = (c.indexOf(',') > -1 || c.indexOf('"') > -1 || c.indexOf('\n') > -1)
            ? '"' + c.replace(/"/g, '""') + '"' : c;
          row += (j > 0 ? ',' : '') + cell;
        }
        csv += row + '\n';
      }
      this._triggerDownload(
        new Blob([csv], { type: 'text/csv;charset=utf-8;' }),
        'calendar_export.csv'
      );
      this._notifyFramework();
    }

    /* ---- Excel download (.xls via HTML table) ---- */

    _onXlsClick() {
      if (!this._rows.length) return;
      var xls = [
        '<html xmlns:o="urn:schemas-microsoft-com:office:office"',
        ' xmlns:x="urn:schemas-microsoft-com:office:excel"',
        ' xmlns="http://www.w3.org/TR/REC-html40">',
        '<head><meta charset="UTF-8">',
        '<style>',
        '  th { background:#0070f2; color:#ffffff; font-weight:bold; border:1px solid #ccc; padding:5px 8px; }',
        '  td { border:1px solid #ccc; padding:4px 8px; font-size:13px; }',
        '  tr.ev { background:#e8f3ff; }',
        '</style>',
        '</head><body><table>'
      ].join('');

      /* header row */
      xls += '<tr>';
      for (var h = 0; h < this._headers.length; h++) {
        var hVal = this._headers[h] || '';
        xls += '<th>' + hVal.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</th>';
      }
      xls += '</tr>';

      /* data rows */
      for (var r = 0; r < this._rows.length; r++) {
        var rowData = this._rows[r];
        var rt      = (rowData[0] || '').trim();
        var rowCls  = rt === 'Event' ? ' class="ev"' : '';
        xls += '<tr' + rowCls + '>';
        for (var c = 0; c < this._headers.length; c++) {
          var cv = (rowData[c] !== undefined && rowData[c] !== 'undefined') ? rowData[c] : '';
          xls += '<td>' + cv.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</td>';
        }
        xls += '</tr>';
      }

      xls += '</table></body></html>';
      this._triggerDownload(
        new Blob([xls], { type: 'application/vnd.ms-excel;charset=utf-8;' }),
        'calendar_export.xls'
      );
      this._notifyFramework();
    }

    _triggerDownload(blob, filename) {
      var url = URL.createObjectURL(blob);
      var a   = document.createElement('a');
      a.href  = url; a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    _notifyFramework() {
      this.dispatchEvent(new CustomEvent('propertiesChanged', { detail: { properties: {} } }));
    }

    /* ---- render ---- */

    _render() {
      var hasData = this._headers.length > 0 && this._rows.length > 0;

      /* toolbar pills */
      var tl       = this._shadowRoot.querySelector('.ct-tl');
      var oldPills = tl.querySelectorAll('.ct-pill');
      for (var p = 0; p < oldPills.length; p++) { oldPills[p].remove(); }

      var csvBtn = this._shadowRoot.getElementById('ct-dl-csv');
      var xlsBtn = this._shadowRoot.getElementById('ct-dl-xls');
      csvBtn.disabled = !hasData;
      xlsBtn.disabled = !hasData;

      if (hasData) {
        var evCount = 0, chCount = 0;
        for (var ri = 0; ri < this._rows.length; ri++) {
          if ((this._rows[ri][0] || '').trim() === 'Event') { evCount++; } else { chCount++; }
        }
        var p1 = document.createElement('span');
        p1.className   = 'ct-pill ct-pill-blue';
        p1.textContent = evCount + (evCount === 1 ? ' Process' : ' Processes');
        tl.appendChild(p1);
        var p2 = document.createElement('span');
        p2.className   = 'ct-pill ct-pill-grey';
        p2.textContent = chCount + (chCount === 1 ? ' Child' : ' Children');
        tl.appendChild(p2);
      }

      var content = this._shadowRoot.getElementById('ct-content');

      if (!hasData) {
        content.innerHTML = [
          '<div class="ct-empty">',
          '  <div class="ct-empty-icon">&#128197;</div>',
          '  <div class="ct-empty-title">No data loaded</div>',
          '  <div class="ct-empty-hint">Run the SAC script to load calendar data.<br>The table will appear here automatically.</div>',
          '</div>'
        ].join('');
        return;
      }

      /* compute total table width */
      var totalWidth = 0;
      for (var hi = 0; hi < this._headers.length; hi++) {
        var hName = this._headers[hi] || '';
        var cfg   = COL_CFG[hName] || { width: 130 };
        totalWidth += cfg.width;
      }

      /* colgroup */
      var html = '<div class="ct-tbl-wrap"><table style="width:' + totalWidth + 'px"><colgroup>';
      for (var ci = 0; ci < this._headers.length; ci++) {
        var hN   = this._headers[ci] || '';
        var cfg2 = COL_CFG[hN] || { width: 130 };
        html += '<col style="width:' + cfg2.width + 'px">';
      }
      html += '</colgroup>';

      /* thead */
      html += '<thead><tr>';
      for (var hj = 0; hj < this._headers.length; hj++) {
        var hdr  = this._headers[hj] || '';
        var cfg3 = COL_CFG[hdr] || {};
        var sep  = cfg3.ctx ? ' ct-ctx-sep' : '';
        html += '<th class="' + sep + '" title="' + this._esc(hdr) + '">' +
                  this._esc(hdr) +
                  '<div class="ct-resizer"></div>' +
                '</th>';
      }
      html += '</tr></thead>';

      /* tbody */
      html += '<tbody>';
      for (var rr = 0; rr < this._rows.length; rr++) {
        var row  = this._rows[rr];
        var rt   = (row[0] || '').trim();
        html += '<tr class="' + (rt === 'Event' ? 'ct-row-ev' : 'ct-row-ch') + '">';

        for (var cc = 0; cc < this._headers.length; cc++) {
          var rawCell = (row[cc] !== undefined) ? row[cc] : '';
          if (rawCell === 'undefined') { rawCell = ''; }
          var hdrName = this._headers[cc] || '';
          var colCfg  = COL_CFG[hdrName] || { type: 'text' };
          var sepTd   = colCfg.ctx ? ' ct-ctx-sep' : '';
          var content_cell;

          if (colCfg.type === 'type') {
            content_cell = rt === 'Event'
              ? '<span class="ct-badge ct-badge-ev">Event</span>'
              : '<span class="ct-badge ct-badge-ch">Child</span>';
          } else if (colCfg.type === 'status') {
            content_cell = '<span class="ct-status ' + this._statusClass(rawCell) + '">' + this._esc(rawCell) + '</span>';
          } else if (colCfg.type === 'progress') {
            content_cell = this._progressBar(rawCell);
          } else if (colCfg.type === 'id-plain') {
            var idVal = this._esc(rawCell);
            content_cell = idVal ? '<span class="ct-id-plain">' + idVal + '</span>' : '';
          } else {
            content_cell = this._esc(rawCell);
          }

          html += '<td class="' + sepTd + '" title="' + this._esc(rawCell) + '" data-val="' + this._esc(rawCell) + '">' + content_cell + '</td>';
        }
        html += '</tr>';
      }

      html += '</tbody></table></div>';
      html += '<div class="ct-footer">' + this._rows.length + ' rows &nbsp;|&nbsp; ' + this._headers.length + ' columns &nbsp;|&nbsp; Click any cell to copy its value</div>';
      content.innerHTML = html;

      /* wire interactivity after DOM is built */
      this._wireResizers();
      this._wireCellClicks();
    }
  }

  customElements.define('com-custom-calendartable', CalendarTable);
})();
